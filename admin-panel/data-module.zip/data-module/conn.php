<?php 

$uid_= "root";
$pwd_ = "";
$db = "weedapp";
$server = "localhost";

$conn = mysqli_connect($server, $uid_, $pwd_, $db);

if (!$conn) die("Database Error");

// <?php 

// $uid_= "MilkyTech";
// $pwd_ = "'e\jK38!0|zn";
// $db = "herbicidesData-3136358574";
// $server = "shareddb-z.hosting.stackcp.net";

// $conn = mysqli_connect($server, $uid_, $pwd_, $db);

// if (!$conn) die("Database Error");